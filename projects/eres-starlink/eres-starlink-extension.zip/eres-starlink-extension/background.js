const API = "https://unitedstarlinktracker.com/api/check-flight";
const MAX_CONCURRENT = 4;
const MIN = 60 * 1000;
const HOUR = 60 * MIN;

const inflight = new Map();
const queue = [];
let active = 0;

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "slk-check") return false;
  check(msg)
    .catch(() => ({ status: "unknown", detail: "Lookup failed", retry: true }))
    .then(sendResponse);
  return true;
});

async function check({ flight, date, origin = "", destination = "" }) {
  const leg = { origin, destination };
  const key = `slk:${flight}:${date}:${origin}-${destination}`;
  const cached = (await chrome.storage.session.get(key))[key];
  if (cached && cached.expires > Date.now()) return cached.result;

  if (!inflight.has(key)) {
    const p = schedule(() => fetchStatus(flight, date, leg))
      .then(async ({ result, ttl }) => {
        try {
          await chrome.storage.session.set({ [key]: { result, expires: Date.now() + ttl } });
        } catch {}
        return result;
      })
      .finally(() => inflight.delete(key));
    inflight.set(key, p);
  }
  return inflight.get(key);
}

function schedule(task) {
  return new Promise((resolve, reject) => {
    queue.push({ task, resolve, reject });
    pump();
  });
}

function pump() {
  while (active < MAX_CONCURRENT && queue.length) {
    const { task, resolve, reject } = queue.shift();
    active++;
    task().then(resolve, reject).finally(() => {
      active--;
      pump();
    });
  }
}

async function fetchStatus(flight, date, leg) {
  const params = new URLSearchParams({ flight_number: flight, date });
  if (leg.origin && leg.destination) {
    params.set("origin", leg.origin);
    params.set("destination", leg.destination);
  }
  const url = `${API}?${params}`;
  let res, json;
  try {
    res = await fetch(url, { signal: AbortSignal.timeout(15000) });
    json = await res.json();
  } catch {
    return { result: { status: "unknown", detail: "Lookup failed", retry: true }, ttl: MIN };
  }
  if (!res.ok) {
    const transient = res.status >= 500 || res.status === 429;
    const result = { status: "unknown", detail: json?.error || `HTTP ${res.status}`, retry: transient };
    return { result, ttl: transient ? MIN : 24 * HOUR };
  }
  return interpret(json, date, leg);
}

function interpret(json, date, leg) {
  const onLeg = (from, to) => !leg.origin || (from === leg.origin && to === leg.destination);
  if (!json || typeof json !== "object") return { result: { status: "unknown", detail: "No data", retry: true }, ttl: MIN };
  if (json.hasStarlink === true) {
    const flights = json.flights || [];
    const f = flights.find((x) => onLeg(x.departure_airport, x.arrival_airport)) ?? flights[0];
    const plane = f ? [f.aircraft_type, f.tail_number].filter(Boolean).join(" · ") : "";
    return { result: { status: "yes", detail: plane }, ttl: 2 * HOUR };
  }
  if (json.hasStarlink === false) {
    const segs = json.fallback?.segments || [];
    const s = segs.find((x) => onLeg(x.origin, x.destination)) ?? segs[0];
    const parts = s ? [s.aircraft_model, s.tail_number, s.verified_wifi && `Wi-Fi: ${s.verified_wifi}`] : [];
    const status = s?.hasStarlink === true ? "yes" : "no";
    return { result: { status, detail: parts.filter(Boolean).join(" · ") }, ttl: 2 * HOUR };
  }
  const p = json.prediction?.probability;
  const detail = typeof p === "number" ? `Not yet assigned · ~${Math.round(p * 100)}% Starlink odds` : "No data";
  const daysOut = (Date.parse(date) - Date.now()) / (24 * HOUR);
  return { result: { status: "unknown", detail }, ttl: daysOut > 2 ? 12 * HOUR : 15 * MIN };
}
