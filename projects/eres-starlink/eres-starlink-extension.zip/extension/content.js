(() => {
  const SEL = {
    segment: '[class*="__fsrDetailsEachLine--"]',
    flightNum: '[class*="__flightNumberStyle--"]',
    flightNumMobile: '[class*="__flightNumberStyleMobile--"]',
    mainDetails: '[class*="__flightSearchMainDetails--"]',
    time: '[class*="__timezoneEffect--"]',
    airports: '[class*="__airportDetails--"]',
    daysDiff: '[class*="__daysDifference--"]',
    row: '[class*="__entireRow--"]',
    planFlightNum: '[class*="TravelPlansDetails__flightNo--"]',
    planDay: '[class*="TravelPlansDetails__routeDay--"]',
    planDate: '[class*="TravelPlansDetails__travelDate--"]',
    planJourney: '[class*="TravelPlansDetails__journeyDtls--"]',
  };
  const MONTHS = { jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5, jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11 };
  const DAY = 86400000;
  const RETRY_MS = 60000;
  const LABELS = { yes: "Starlink Wi-Fi", no: "No Starlink", unknown: "Starlink status unknown", loading: "Checking Starlink…" };

  function searchDate() {
    const candidates = [
      ...[...document.querySelectorAll('[class*="FsrCalendar__FsrDate--"]')].map((e) => e.textContent),
      document.querySelector("input#departDate")?.value,
    ];
    for (const text of candidates) {
      const m = text && text.match(/([A-Za-z]{3})[a-z]*\.?\s+(\d{1,2}),?\s+(\d{4})/);
      if (m && m[1].toLowerCase() in MONTHS) return Date.UTC(+m[3], MONTHS[m[1].toLowerCase()], +m[2]);
    }
    return null;
  }

  function parseTime(timeEl) {
    const m = timeEl?.textContent.match(/(\d{1,2}):(\d{2})/);
    if (!m) return null;
    const ampm = (timeEl.nextElementSibling?.textContent || "").trim().toUpperCase();
    let h = +m[1] % 12;
    if (ampm.startsWith("P")) h += 12;
    return h * 60 + +m[2];
  }

  function parseShortDate(text, refUtc) {
    const m = text && text.match(/([A-Za-z]{3})[a-z]*\.?\s+(\d{1,2})/g);
    const last = m && m[m.length - 1].match(/([A-Za-z]{3})[a-z]*\.?\s+(\d{1,2})/);
    if (!last || !(last[1].toLowerCase() in MONTHS)) return null;
    const ref = new Date(refUtc);
    let d = Date.UTC(ref.getUTCFullYear(), MONTHS[last[1].toLowerCase()], +last[2]);
    if (d < refUtc - 180 * DAY) d = Date.UTC(ref.getUTCFullYear() + 1, MONTHS[last[1].toLowerCase()], +last[2]);
    return d;
  }

  const iso = (utc) => new Date(utc).toISOString().slice(0, 10);

  function segmentInfo(seg) {
    const nums = seg.querySelectorAll(SEL.flightNum);
    if (nums.length < 2) return null;
    const carrier = nums[0].textContent.trim().toUpperCase();
    const digits = nums[1].textContent.trim();
    if (!/^\d{1,4}$/.test(digits)) return null;
    const times = seg.querySelector(SEL.mainDetails)?.querySelectorAll(SEL.time) || [];
    const airportsEl = seg.querySelector(SEL.airports);
    const arrDiff = airportsEl?.querySelector(SEL.daysDiff)?.textContent;
    const codes = [...(airportsEl?.querySelectorAll("span") || [])]
      .map((s) => s.textContent.trim())
      .filter((t) => /^[A-Z]{3}$/.test(t));
    return {
      anchor: nums[1],
      mobile: seg.querySelector(SEL.flightNumMobile),
      carrier,
      flight: `${carrier}${parseInt(digits, 10)}`,
      dep: parseTime(times[0]),
      arr: parseTime(times[1]),
      arrDiff,
      origin: codes.length >= 2 ? codes[0] : "",
      destination: codes.length >= 2 ? codes[1] : "",
    };
  }

  // ERES only shows arrival dates, so each connecting segment's departure date is carried forward from the previous arrival.
  function itinerarySegments(row, baseUtc) {
    const out = [];
    let prev = null;
    for (const seg of row.querySelectorAll(SEL.segment)) {
      const info = segmentInfo(seg);
      if (!info) continue;
      let depUtc = baseUtc;
      if (prev) {
        depUtc = prev.arrUtc;
        if (info.dep != null && prev.arr != null && info.dep < prev.arr) depUtc += DAY;
      }
      let arrUtc = parseShortDate(info.arrDiff, baseUtc);
      if (arrUtc == null || arrUtc < depUtc) {
        arrUtc = depUtc;
        if (info.dep != null && info.arr != null && info.arr < info.dep) arrUtc += DAY;
      }
      const item = { ...info, date: iso(depUtc), arrUtc };
      out.push(item);
      prev = item;
    }
    return out;
  }

  function makeDot(variant) {
    const dot = document.createElement("span");
    dot.className = `slk-dot slk-dot--${variant}`;
    dot.setAttribute("role", "img");
    return dot;
  }

  // Travel plans details pane: "<span class=flightNo>UA1363 | Boeing 777-200</span>" inside "Mon, Nov 02, 2026".
  // React may render these as several adjacent text nodes, so parse full textContent and map offsets back to nodes.
  function planSegments() {
    const out = [];
    for (const num of document.querySelectorAll(SEL.planFlightNum)) {
      const m = num.textContent.match(/^\s*([A-Z0-9]{2})\s*(\d{1,4})(?!\d)/);
      if (!m) continue;
      const d = num.closest(SEL.planDay)?.textContent.match(/([A-Za-z]{3})[a-z]*\.?\s+(\d{1,2}),?\s+(\d{4})/);
      if (!d || !(d[1].toLowerCase() in MONTHS)) continue;
      const text = textNodeEndingAt(num, m[0].length);
      if (!text) continue;
      let journey = num.closest(SEL.planDate)?.previousElementSibling;
      while (journey && !journey.matches(SEL.planJourney)) journey = journey.previousElementSibling;
      const codes = [...(journey?.textContent.matchAll(/\(([A-Z]{3})\)/g) || [])].map((c) => c[1]);
      const carrier = m[1];
      out.push({
        text,
        carrier,
        flight: `${carrier}${parseInt(m[2], 10)}`,
        date: iso(Date.UTC(+d[3], MONTHS[d[1].toLowerCase()], +d[2])),
        origin: codes.length === 2 ? codes[0] : "",
        destination: codes.length === 2 ? codes[1] : "",
      });
    }
    return out;
  }

  // Returns the text node whose end is at character `end` of el's text, splitting a node only when the flight number shares it with other text.
  function textNodeEndingAt(el, end) {
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    let pos = 0;
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const len = n.data.length;
      if (pos + len >= end) {
        if (pos + len > end) n.splitText(end - pos);
        return n;
      }
      pos += len;
    }
    return null;
  }

  function ensurePlanDot(item) {
    let dot = item.text.nextSibling;
    if (!dot?.classList?.contains("slk-dot--plan")) {
      dot = item.text.parentElement.closest(SEL.planFlightNum)?.querySelector(".slk-dot--plan") || makeDot("plan");
      item.text.after(dot);
    }
    return [dot];
  }

  function ensureDots(item) {
    let desktop = item.anchor.parentElement.querySelector(":scope > .slk-dot--desktop");
    if (!desktop) desktop = makeDot("desktop");
    if (item.anchor.nextElementSibling !== desktop) item.anchor.after(desktop);
    const dots = [desktop];
    if (item.mobile) {
      let mobile = item.mobile.querySelector(":scope > .slk-dot--mobile");
      if (!mobile) mobile = makeDot("mobile");
      if (item.mobile.firstElementChild !== mobile) item.mobile.prepend(mobile);
      dots.push(mobile);
    }
    return dots;
  }

  function setState(dots, status, detail) {
    const text = detail ? `${LABELS[status]} — ${detail}` : LABELS[status];
    for (const dot of dots) {
      dot.dataset.slkState = status;
      dot.title = text;
      dot.setAttribute("aria-label", text);
    }
  }

  function annotate(item, dots) {
    const key = `${item.flight}|${item.date}|${item.origin}-${item.destination}`;
    if (dots.every((d) => d.dataset.slkKey === key)) return;
    for (const d of dots) d.dataset.slkKey = key;

    if (item.carrier !== "UA") {
      setState(dots, "unknown", "Only United flights are tracked");
      return;
    }
    setState(dots, "loading");
    const onResult = (res) => {
      const live = dots.filter((d) => d.isConnected && d.dataset.slkKey === key);
      const failed = chrome.runtime.lastError || !res;
      setState(live, failed ? "unknown" : res.status, failed ? "Lookup failed" : res.detail);
      if (failed || res.retry) {
        setTimeout(() => {
          for (const d of live) if (d.dataset.slkKey === key) delete d.dataset.slkKey;
          schedule();
        }, RETRY_MS);
      }
    };
    try {
      chrome.runtime.sendMessage({ type: "slk-check", flight: item.flight, date: item.date, origin: item.origin, destination: item.destination }, onResult);
    } catch {
      onResult(null);
    }
  }

  function scan() {
    if (!chrome.runtime?.id) {
      observer.disconnect();
      return;
    }
    for (const item of planSegments()) annotate(item, ensurePlanDot(item));
    const base = searchDate();
    if (base == null) return;
    for (const row of document.querySelectorAll(SEL.row)) {
      for (const item of itinerarySegments(row, base)) annotate(item, ensureDots(item));
    }
  }

  let pending = false;
  const schedule = () => {
    if (pending) return;
    pending = true;
    setTimeout(() => {
      pending = false;
      scan();
    }, 250);
  };

  const observer = new MutationObserver(schedule);
  observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  schedule();
})();
