const API = "https://unitedstarlinktracker.com/api/check-flight";
const MAX_CONCURRENT = 4;

const inflight = new Map();
const queue = [];
let active = 0;

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "slk-check") return false;
  check(msg)
    .catch(() => ({ status: "unknown", detail: "Lookup failed", retry: true }))
    .then(sendResponse);
  return true;
});

async function check({ flight, date, origin = "", destination = "" }) {
  const leg = { origin, destination };
  const key = `slk:${flight}:${date}:${origin}-${destination}`;
  if (!inflight.has(key)) {
    const p = schedule(() => fetchStatus(flight, date, leg)).finally(() => inflight.delete(key));
    inflight.set(key, p);
  }
  return inflight.get(key);
}

function schedule(task) {
  return new Promise((resolve, reject) => {
    queue.push({ task, resolve, reject });
    pump();
  });
}

function pump() {
  while (active < MAX_CONCURRENT && queue.length) {
    const { task, resolve, reject } = queue.shift();
    active++;
    task().then(resolve, reject).finally(() => {
      active--;
      pump();
    });
  }
}

async function fetchStatus(flight, date, leg) {
  const params = new URLSearchParams({ flight_number: flight, date });
  if (leg.origin && leg.destination) {
    params.set("origin", leg.origin);
    params.set("destination", leg.destination);
  }
  const url = `${API}?${params}`;
  let res, json;
  try {
    res = await fetch(url, { signal: AbortSignal.timeout(15000) });
    json = await res.json();
  } catch {
    return { status: "unknown", detail: "Lookup failed", retry: true };
  }
  if (!res.ok) {
    const transient = res.status >= 500 || res.status === 429;
    return { status: "unknown", detail: json?.error || `HTTP ${res.status}`, retry: transient };
  }
  return interpret(json, leg);
}

function interpret(json, leg) {
  const onLeg = (from, to) => !leg.origin || (from === leg.origin && to === leg.destination);
  if (!json || typeof json !== "object") return { status: "unknown", detail: "No data", retry: true };
  if (json.hasStarlink === true) {
    const flights = json.flights || [];
    const f = flights.find((x) => onLeg(x.departure_airport, x.arrival_airport)) ?? flights[0];
    const plane = f ? [f.aircraft_type, f.tail_number].filter(Boolean).join(" · ") : "";
    return { status: "yes", detail: plane };
  }
  if (json.hasStarlink === false) {
    const segs = json.fallback?.segments || [];
    const s = segs.find((x) => onLeg(x.origin, x.destination)) ?? segs[0];
    const parts = s ? [s.aircraft_model, s.tail_number, s.verified_wifi && `Wi-Fi: ${s.verified_wifi}`] : [];
    const status = s?.hasStarlink === true ? "yes" : "no";
    return { status, detail: parts.filter(Boolean).join(" · ") };
  }
  const p = json.prediction?.probability;
  const detail = typeof p === "number" ? `Not yet assigned · ~${Math.round(p * 100)}% Starlink odds` : "No data";
  return { status: "unknown", detail };
}
